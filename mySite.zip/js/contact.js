function questionSent() {
    alert("Wysłano wiadomość \"Blank\"");
};